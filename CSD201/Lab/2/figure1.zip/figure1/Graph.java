/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figure1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author admin
 */
public class Graph {

    private int[][] adjacencyMatrix;
    private String[] label;
    private int n;

    // Constructor
    public Graph() {
    }

    // Set adjacency matrix
    public void setAMatrix(int[][] b, int m) {
        n = m;
        adjacencyMatrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                adjacencyMatrix[i][j] = b[i][j];
            }
        }
    }

    // Set labels for vertices
    public void setLabel(String[] c) {
        label = new String[n];
        for (int i = 0; i < n; i++) {
            label[i] = c[i];
        }
    }

    // Breadth-first traverse
    public void breadthFirstTraverse() {
        boolean[] visited = new boolean[n];
        Queue<Integer> queue = new LinkedList<>();
        for (int i = 0; i < n; i++) {
            if (!visited[i]) {
                visited[i] = true;
                System.out.print(label[i] + " ");
                queue.add(i);
                while (!queue.isEmpty()) {
                    int v = queue.poll();
                    for (int j = 0; j < n; j++) {
                        if (adjacencyMatrix[v][j] == 1 && !visited[j]) {
                            visited[j] = true;
                            System.out.print(label[j] + " ");
                            queue.add(j);
                        }
                    }
                }
            }
        }
        System.out.println();
    }

    // Depth-first traverse
    public void depthFirstTraverse() {
        boolean[] visited = new boolean[n];
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i < n; i++) {
            if (!visited[i]) {
                visited[i] = true;
                System.out.print(label[i] + " ");
                stack.push(i);
                while (!stack.isEmpty()) {
                    int v = stack.pop();
                    for (int j = 0; j < n; j++) {
                        if (adjacencyMatrix[v][j] == 1 && !visited[j]) {
                            visited[j] = true;
                            System.out.print(label[j] + " ");
                            stack.push(j);
                        }
                    }
                }
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        try {
            // Read adjacency matrix from file
            Scanner scanner = new Scanner(new File("adjacency_matrix.txt"));
            int n = 6; // Number of vertices
            int[][] matrix = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    matrix[i][j] = scanner.nextInt();
                }
            }

            // Read vertex labels from file
            Scanner labelScanner = new Scanner(new File("vertex_labels.txt"));
            String[] labels = new String[n];
            for (int i = 0; i < n; i++) {
                labels[i] = labelScanner.next();
            }

            // Create and configure the graph
            Graph graph = new Graph();
            graph.setAMatrix(matrix, n);
            graph.setLabel(labels);

            // Perform breadth-first and depth-first traversals
            System.out.println("Breadth-first traverse:");
            graph.breadthFirstTraverse();
            System.out.println("Depth-first traverse:");
            graph.depthFirstTraverse();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
